<?php if(is_active_sidebar('event-sidebar')){ ?>
        <aside id="sidebar-event" class="sidebar">
            <?php  dynamic_sidebar('event-sidebar'); ?>
        </aside><!-- .sidebar -->
<?php } ?>